create
    definer = root@localhost procedure simpleproc(OUT param1 int)
SELECT COUNT(*) INTO param1 FROM cqupt;

