create
    definer = root@localhost procedure second_p()
select current_date from cqupt;

