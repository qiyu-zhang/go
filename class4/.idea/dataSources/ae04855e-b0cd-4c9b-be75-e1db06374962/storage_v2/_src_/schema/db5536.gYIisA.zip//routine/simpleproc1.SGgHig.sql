create
    definer = root@localhost procedure simpleproc1(IN param1 int)
    SET @x = param1 - 100;

