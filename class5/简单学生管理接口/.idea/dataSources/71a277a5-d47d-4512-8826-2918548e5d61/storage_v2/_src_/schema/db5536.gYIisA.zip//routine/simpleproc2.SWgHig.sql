create
    definer = root@localhost procedure simpleproc2(IN paraml int)
    Set @x = paraml * 10;

